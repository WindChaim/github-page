import java.util.*;
import java.util.ArrayList;
import java.util.Random;

//Taken from Petamind

/**
 * This class is a dummy chat bot
 */
public class MyBot {
    HashMap<String, String> knowledge = new HashMap<>();

    ArrayList<String> thoughts = new ArrayList<>();

    Random r = new Random();

    /**
     * This is a default constructor.
     */
    public MyBot() {
        knowledge.put("Hi.", "Hello... Please to meet you!");
        knowledge.put("how are you?", "Great! And you?");
        knowledge.put("good.",  "That's good!");
        knowledge.put("what time is it?", "Look at your watch!");
        knowledge.put("i don't have a watch.", "I don't have a watch either!");
        knowledge.put("what is your favorite book?", "What's a book?");
        knowledge.put("what do you want to learn?", "Thinking...");
        knowledge.put("what do you think about?", "Thinking...");
        knowledge.put("who are you?", "I am Bot!");
        thoughts.add("What is food?");
        thoughts.add("How do you walk?");
        thoughts.add("Where is the Eiffel Tower?");
        thoughts.add("Is water wet?");
    }

    /**
     * @param question This is user input as string
     */
    public void answer(String question) {
        Set<String> keys = knowledge.keySet();
        for (String key : keys){
            String lowerKey = key.toLowerCase();
            String lowerQuestion = question.toLowerCase();

            if (lowerKey.contains(lowerQuestion)) {
                System.out.println("Bot: " + knowledge.get(key));
                if (knowledge.get(key).equals("Thinking...")){
                    try {
                        Thread.sleep(1500);
                    } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt(); // very important
                        break;
                    }
                    if (thoughts.size() > 0) {
                        int rand = r.nextInt(0, thoughts.size());
                            System.out.println("Bot: " + thoughts.get(rand));
                            System.out.print("User: ");
                            Scanner sc = new Scanner(System.in);
                            String lesson = sc.nextLine();
                            System.out.println("Bot: Oh, I understand now!");
                            knowledge.put(thoughts.get(rand), lesson);
                            thoughts.remove(rand);
                            return;
                    }
                    else System.out.println("Bot: Nothing.");
                }
                return;//break
            }
        }
        trainMe(question);
    }

    public void trainMe(String question) {
        System.out.println("Bot: Sorry, I'm dumb! How should I reply?");
        System.out.print("User suggestion: ");
        Scanner sc = new Scanner(System.in);
        String userInput = sc.nextLine();
        knowledge.put(question, userInput);
    }

}